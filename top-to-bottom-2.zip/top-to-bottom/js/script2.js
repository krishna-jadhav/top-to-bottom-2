jQuery(function ($) {
    "use strict"; 
    /* ===================================
            Scroll
    ====================================== */  
    $(window).on('scroll', function () {
        if ($(this).scrollTop() > 220) { // Set position from top to add class
            $('header').addClass('header-appear');
        }
        else {
            $('header').removeClass('header-appear');
        }
    });


    //scroll sections 
        $(".scroll").on("click", function (event) {
            event.preventDefault();
            $("html,body").animate({
                scrollTop: $(this.hash).offset().top - 60}, 1200);
        });   

        // mobileToggle
        $(document).ready(function(){
            $(".header button").click(function(){
              $("#nav-main").addClass("intro"); 
              $("#nav-main").removeClass("intro");
            });
          }); 
        
});

// mobileToggle
/*
function mobileToggle() {
    var element = document.getElementById("nav-main");
    element.classList.toggle("navstyle");
 }
 */


