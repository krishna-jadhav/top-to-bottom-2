 

   $(document).ready(function(){ 

//     $(".logo-main").slideDown(2000);

 

 $(function() {
  $('.loader').fadeOut();
});

});


$(document).ready(function(){
	$("input").click(function()	{
    // $("div").hide();
    // $("p").hide("slow");
    // $("p").hide(1000);    
    // $("p").show("slow");    
    // $("p").toggle("slow");
    // $("p").fadeIn("slow");
    // $("p").fadeOut("slow");
    // $("p").fadeToggle("slow");
    // $("p").fadeTo("slow");   
    // $("p").slideDown("slow"); 
    // $("p").slideUp("slow"); 
    $("p").slideToggle("slow"); 
	});
});

// $(document).ready(function(){ 
  
//   $("p").mouseenter(function(){
//     $(this).fadeTo("slow",0.50); 
//   });
//   $("p").mouseleave(function(){
//     $(this).fadeTo("slow",1); 
//   });

// });



 